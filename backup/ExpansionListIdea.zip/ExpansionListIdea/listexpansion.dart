import 'package:ReadHeadlines/webview.dart';
import 'package:flutter/material.dart';

class ListExpansion extends StatefulWidget {
  final List snapshot;
  ListExpansion({this.snapshot});
  @override
  _ListExpansionState createState() => _ListExpansionState(snapshot: snapshot);
}

class _ListExpansionState extends State<ListExpansion> {
  final List snapshot;
  _ListExpansionState({this.snapshot});
  @override
  Widget build(BuildContext context) {
    return ExpansionPanelList(
        expansionCallback: (int index, bool isExpanded) {
          setState(() {
            snapshot[index].isExpanded = !snapshot[index].isExpanded;
          });
        },
        children: snapshot.map((data) {
          return ExpansionPanel(
            canTapOnHeader: true,
            headerBuilder: (BuildContext context, bool isExpanded) {
              return ListTile(
                title: Text(data.title.toString()),
                subtitle: Text(data.published.toString()),
              );
            },
            isExpanded: data.isExpanded,
            body: Row(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    IconButton(icon: Icon(Icons.open_in_new), onPressed: null),
                    Text('Open')
                  ],
                )
              ],
            ),
          );
        }).toList());
  }
}

void webviewcaller(BuildContext context, String url) {
  Navigator.push(
      context, MaterialPageRoute(builder: (context) => WebViewPage(url)));
}

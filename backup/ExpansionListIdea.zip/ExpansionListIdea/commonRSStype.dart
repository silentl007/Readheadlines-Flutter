import 'package:ReadHeadlines/listexpansion.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:loading_animations/loading_animations.dart';
import 'dart:async';
import 'dart:convert';

class RSScommon extends StatefulWidget {
  final String url;
  RSScommon(this.url);
  @override
  _RSScommonState createState() => _RSScommonState(this.url);
}

class _RSScommonState extends State<RSScommon> {
  final String _resolve;
  _RSScommonState(this._resolve);
  List<ParsedData> feeddata = <ParsedData>[];
  Future<List> _feedprocess() async {
    try {
      var feed = await http.get(_resolve);
      var jsonData = jsonDecode(feed.body);
      if (jsonData != null) {
        for (var info in jsonData) {
          ParsedData parsed = ParsedData(
              title: info["title"],
              published: info['published'],
              link: info['link'],
              isExpanded: false);
          feeddata.add(parsed);
        }
      }
      print('------------SUCCESS--------------');
      return feeddata;
    } catch (e) {
      List feeddata = ['failed'];
      print('-------------------error------------------');
      print(e);
      print('-------------------error------------------');
      return feeddata;
    }
  }

  void _reset() {
    // reset function for no internet
    setState(() {
      return feeddata;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: FutureBuilder(
        future: _feedprocess(),
        builder: (BuildContext context, AsyncSnapshot<List> snapshot) {
          if (snapshot.hasData == false) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                LoadingBouncingGrid
                    .square(), // loading animation for fetching data
                Text('Fetching Data')
              ],
            );
          } else if (snapshot.data[0] == 'failed') {
            return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('No Internet Connection'), // reset button if no internet
                  RaisedButton(child: Text('Retry'), onPressed: _reset),
                ]);
          }
          return ListView.builder(
            itemCount: snapshot.data.length,
            itemBuilder: (BuildContext context, int index) {
              return ListExpansion(snapshot: snapshot.data);
            },
          );
        },
      ),
    );
  }
}

class ParsedData {
  final String title;
  final String published;
  final String link;
  bool isExpanded;

  ParsedData({this.title, this.published, this.link, this.isExpanded});
}


import 'package:flutter/material.dart';

class WashingtonPosts extends StatefulWidget {
  @override
  _WashingtonPostsState createState() => _WashingtonPostsState();
}

class _WashingtonPostsState extends State<WashingtonPosts> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text('Coming Soon'),
      ), 
    );
  }
}
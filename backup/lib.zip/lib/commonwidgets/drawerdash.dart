import 'package:flutter/material.dart';
import 'package:ReadHeadlines/commonwidgets/expansionpanel.dart';

class DrawerDash extends StatefulWidget {
  final String titletext;
  DrawerDash({this.titletext});
  @override
  _DrawerDashState createState() => _DrawerDashState(titletext);
}

class _DrawerDashState extends State<DrawerDash> {
  final String titletext;
  _DrawerDashState(this.titletext);
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          DrawerHeader(
            child: Center(
              child: Text('PlaceHolder'),
            ),
          ),
          Container(
            color: Colors.indigo,
            child: Column(
              children: [
                ExtenderDrawer(titletext),
                Card(
                  child: ListTile(
                    title: Text('Settings'),
                    leading: Icon(Icons.settings),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:ReadHeadlines/commonwidgets/webview.dart';
import 'package:flutter/material.dart';
import 'package:share/share.dart';

class SubtitleContent extends StatelessWidget {
  final String published;
  final String link;
  SubtitleContent({this.link, this.published});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
        published,
      ),
      Row(
        children: <Widget>[
          Column(
            children: <Widget>[
              IconButton(
                  icon: Icon(Icons.open_in_new),
                  onPressed: () => webviewcaller(context, link)),
              Text('Open'),
            ],
          ),
          Column(
            children: <Widget>[
              IconButton(
                  icon: Icon(Icons.bookmark_border),
                  onPressed: () => webviewcaller(context, link)),
              Text('Bookmark'),
            ],
          ),
          Column(
            children: <Widget>[
              IconButton(icon: Icon(Icons.share), onPressed: share),
              Text('Share'),
            ],
          )
        ],
      )
    ]);
  }

  void share() {
    String shareurl = link.toString();
    Share.share(shareurl);
  }

  void webviewcaller(BuildContext context, String url) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => WebViewPage(url)));
  }


}

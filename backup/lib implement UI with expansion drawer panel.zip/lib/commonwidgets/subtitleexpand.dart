import 'package:flutter/material.dart';

class SubtitleExpand extends StatefulWidget {
  final String subhead;
  SubtitleExpand({this.subhead});
  @override
  _SubtitleExpandState createState() => _SubtitleExpandState(subhead: subhead);
}

class _SubtitleExpandState extends State<SubtitleExpand> {
  final String subhead;
  _SubtitleExpandState({this.subhead});
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

import 'package:ReadHeadlines/newsscreens/worldnews.dart';
import 'package:flutter/material.dart';
import 'package:ReadHeadlines/newsscreens/sports.dart';

class DrawerExpansion {
  final String title;
  final List body;
  bool isExpanded;
  DrawerExpansion({this.title, this.body, this.isExpanded: false});
}

class TitleIcon {
  final String title;
  final IconData icon;
  bool isExpanded;
  TitleIcon({this.title, this.icon, this.isExpanded: false});
}

class ExtenderDrawer extends StatefulWidget {
  final String titletext;
  ExtenderDrawer(this.titletext);
  @override
  _ExtenderDrawerState createState() => _ExtenderDrawerState(titletext);
}

class _ExtenderDrawerState extends State<ExtenderDrawer> {
  final String titletext;
  _ExtenderDrawerState(this.titletext);
  List<DrawerExpansion> items = <DrawerExpansion>[
    DrawerExpansion(title: 'Categories', body: [
      TitleIcon(title: 'Headlines', icon: Icons.new_releases),
      TitleIcon(title: 'Sports', icon: Icons.sports),
      TitleIcon(title: 'Business', icon: Icons.business),
      TitleIcon(title: 'Travel', icon: Icons.card_travel),
      TitleIcon(title: 'Politics', icon: Icons.policy),
    ])
  ];
  List<DrawerExpansion> sportscategories = <DrawerExpansion>[
    DrawerExpansion(title: 'Sports', body: [
      TitleIcon(title: 'Soccer', icon: Icons.sports_soccer),
      TitleIcon(title: 'Football', icon: Icons.sports_football),
      TitleIcon(title: 'Basketball', icon: Icons.sports_basketball)
    ])
  ];

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ExpansionPanelList(
        elevation: 1,
        expansionCallback: (int index, bool isExpanded) {
          setState(() {
            items[index].isExpanded = !items[index].isExpanded;
          });
        },
        children: items.map((DrawerExpansion item) {
          return ExpansionPanel(
            canTapOnHeader: true,
            headerBuilder: (BuildContext context, bool isExpanded) {
              return ListTile(
                  title: Text(
                    item.title,
                  ),
                  leading: Icon(Icons.category));
            },
            isExpanded: item.isExpanded,
            body: Container(
                color: Colors.purple,
                child: Column(
                  children: item.body.map((categoryname) {
                    if (categoryname.title == 'Sports') {
                      return Card(
                        child: ExpansionPanelList(
                          expansionCallback: (int index, bool isExpanded) {
                            setState(() {
                              sportscategories[index].isExpanded =
                                  !sportscategories[index].isExpanded;
                            });
                          },
                          children: sportscategories.map((sportslist) {
                            return ExpansionPanel(
                              canTapOnHeader: true,
                              headerBuilder:
                                  (BuildContext context, bool isExpanded) {
                                return ListTile(
                                  title: Text(sportslist.title),
                                  leading: Icon(Icons.sports),
                                );
                              },
                              isExpanded: sportslist.isExpanded,
                              body: Container(
                                  color: Colors.black,
                                  child: Column(
                                    children: sportslist.body.map((sportsbody) {
                                      return Card(
                                        child: ListTile(
                                            title: Text(sportsbody.title),
                                            leading: Icon(sportsbody.icon),
                                            onTap: () => categoryroute(
                                                context: context,
                                                category: sportsbody.title)),
                                      );
                                    }).toList(),
                                  )),
                            );
                          }).toList(),
                        ),
                      );
                    }
                    return Card(
                      child: ListTile(
                        title: Text(categoryname.title),
                        leading: Icon(categoryname.icon),
                        onTap: () => categoryroute(
                            context: context, category: categoryname.title),
                      ),
                    );
                  }).toList(),
                )),
          );
        }).toList(),
      ),
    );
  }

  void categoryroute({BuildContext context, String category}) {
    if (category == titletext) {
      Navigator.pop(context);
    } else if (category == 'Business') {
      print(category);
    } else if (category == 'Travel') {
      print(category);
    } else if (category == 'Politics') {
      print(category);
    } else if (category == 'Headlines') {
      Navigator.pop(context);
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => WorldNews()));
    } else if (category == 'Soccer') {
      Navigator.pop(context);
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => Soccer()));
    }
  }
}

// 'Sports': Icons.sports,
// 'Travel': Icons.sports,
// 'World': Icons.sports,
// 'Politics': Icons.sports,
// 'Entertainment': Icons.sports

import 'package:flutter/material.dart';
import 'package:ReadHeadlines/newsscreens/worldnews.dart';

void main(List<String> args) {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        routes: {
          '/world': (context) => WorldNews(),
        },
        theme: ThemeData(
          primarySwatch: Colors.indigo,
        ),
        home: HomeScreen());
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Welcome'),
          centerTitle: true,
        ),
        body: Padding(
          padding: EdgeInsets.all(19),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RaisedButton(
                  child: Row(
                    children: [Text('Local News')],
                  ),
                  onPressed: null),
              RaisedButton(
                  child: Row(
                    children: [Text('World News')],
                  ),
                  onPressed: () {
                    return Navigator.pushNamed(context, '/world');
                  })
            ],
          ),
        ),
      ),
    );
  }
}

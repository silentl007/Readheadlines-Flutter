import 'package:flutter/material.dart';
import 'package:ReadHeadlines/newsscreens/worldnews.dart';

void main(List<String> args) {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        routes: {
          '/world': (context) => WorldNews(),
        },
        theme: ThemeData(
          appBarTheme: AppBarTheme(color: Colors.black),
        ),
        home: HomeScreen());
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // appBar: AppBar(
        //   toolbarHeight: 150,
        //   title: Expanded(child: Text('hello')),
        //   centerTitle: true,
        // ),
        body: Column(
          children: <Widget>[
            Expanded(
              child: GestureDetector(
                onTap: () {
                  print('local news');
                },
                child: Opacity(
                  opacity: .92,
                  child: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/Pg2/localnews.png'),
                            fit: BoxFit.cover)),
                    child: Center(
                      child: Text('Local News',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                            fontWeight: FontWeight.w600,
                          )),
                    ),
                  ),
                ),
              ),
              flex: 1,
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  return Navigator.pushNamed(context, '/world');
                },
                child: Opacity(
                  opacity: .91,
                  child: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/Pg2/worldnews.png'),
                            fit: BoxFit.cover)),
                    child: Center(
                      child: Text('World News',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                            fontWeight: FontWeight.w600,
                          )),
                    ),
                  ),
                ),
              ),
              flex: 1,
            )
          ],
        ),
      ),
    );
  }
}
